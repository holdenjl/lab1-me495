%% ssc_flexshaft_getdata
% ME495: Flexible Shaft (Simscape Model)
% Written by:  John Laidlaw (6/1/2022)
% Last Updated: 6/1/2022

% DESCRIPTION:
% Import data files from the LabView program Frequency Response Main which
% enables the user to define multiple transfer functions (or relationships)
% to plot over a predefined frequency range.   The y-axis may be linear or
% dB.  

% Import experimental data and plot with Simscape model


% UPDATES:
%

clearvars;
close all
clc


%%
testName = 'Frquency Response of Flexible Shaft ';
dB_unit = true;         % Impedance measured in db (true) or ohms (false)
repPhaseWrap = true;    % Attempt to repair phase wrap


%% Define file path and names
% Get username/user directory
if ismac
    % Mac platform
    userdir = getenv('HOME');
elseif isunix
    % Linux platform
    userdir = getenv('HOME');  % Unsure (?)
elseif ispc
    % Windows platform
    userdir= getenv('USERPROFILE');
else
    disp('Platform not supported')
end    
       
% Assemble user's desktop path
mydesktop = strcat(userdir,'\desktop\');            
filter = {'*.*', '*.*';};

% Get data files (File Explorer) - MultiSelect to plot several series
[file,path] = uigetfile(filter,'Select One or More Data Files', mydesktop, 'MultiSelect', 'on');

if ~isequal(file,0) && ~iscell(file)
    file = cellstr(file);
end

% Number of data files selected to plot
nFiles = numel(file); 

if ~isempty(file)
    
    %% Initialize arrays
    fd = cell(nFiles,1);            % cell array of file data
    raw = cell(nFiles,1);
    colHeaders = cell(nFiles,1);
    tfNames = cell(nFiles,1);
    nTrnFn = zeros(nFiles,1);
    is_dB =  zeros(nFiles,1);
    N = zeros(nFiles,1);

    %% Import tab-delimited data files (from LabView)
    for i = 1:nFiles
        % Construct full file path of data.        
        fullPath = strcat(path,file{i});

        % Determine the number or rows for the file header
        headerRowCnt = headerCount(fullPath);
                
        % Import data files and parse to cell array
        fd{i} = importdata(fullPath, '\t', headerRowCnt);
        
        % if the data file has been edited in Excel (or text editor), the
        % header text is lumped in a single cell of the cell array rather
        % than a separate cell array for each column. 
        if isequal(size(fd{i}.textdata,2),1)
            nCol = size(fd{i}.data,2);
            
            % remove blank rows from textdata                     
            fd{i}.textdata = strip(fd{i}.textdata);
            fd{i}.textdata = fd{i}.textdata(not(cellfun(@(x) isempty(x),fd{i}.textdata)));
            
            % transform to uniform,  multi-column cell array
            nRow = size(fd{i}.textdata,1);
            mycell = cell(nRow, nCol);            
            for ki = 1:nRow
                ww = strsplit(string(fd{i}.textdata(ki)),'\t');
                for kj = 1:numel(ww)
                   mycell{ki,kj} = ww{kj};                
                end                
            end            
            fd{i}.textdata = mycell;            
            fd{i}.colheaders = fd{i}.textdata(end,:);            
        end        
                
        % Parse data into variables
        raw{i}.freq = round(fd{i}.data(:,1),1);          % frequency (Hz)
        raw{i}.current = fd{i}.data(:, 2);      % motor current
        raw{i}.mag = fd{i}.data(:, 3);          % Bode magnitude        
        raw{i}.phase = fd{i}.data(:, 4);        % Bode phase angle     
        colHeaders{i} = string(fd{i}.colheaders);                
        
        % number of data points
        N(i) = numel(raw{i}.freq);

    end
    
    % Combine data files
    cellData= cellfun(@(c) struct2cell(c), raw, 'UniformOutput', false);
    cellData2D = horzcat(cellData{:});
    catCellRows = arrayfun(@(row) cat(1,cellData2D{row,:}), (1:size(cellData2D,1))','UniformOutput', false);
    cboData = cell2struct(catCellRows,fieldnames(raw{1}),1);
    
    % sort all data based on frequency field 
    [~, idx] = sort([cboData.freq]);
    sortData = structfun(@(s) s(idx), cboData, 'UniformOutput', false);

    % get array of unique frequencies (to handle replication)
    [uniqFreq, grpIdx, ix] = unique(sortData.freq);
    nReps = accumarray(ix,1);
    
    grpIdxEnd = vertcat(grpIdx(2:end), numel(sortData.freq));
    mag.mean = arrayfun(@(a,b) mean(sortData.mag(a:b)), grpIdx, grpIdxEnd);
    mag.std = arrayfun(@(a,b) std(sortData.mag(a:b)), grpIdx, grpIdxEnd);
    mag.sdom = mag.std./sqrt(nReps);

    % Repair phase wrap before proceeding.
    
    phDiff = arrayfun(@(a,b) round(sortData.phase(a:b)-median(sortData.phase(a:b)),-2),grpIdx, grpIdxEnd, 'UniformOutput', false);
    for j=1:numel(phDiff)-1    
        phArray = cell2mat(phDiff(j));        
        phArray(phArray >= 300) = -360;
        phArray(phArray <= -300) = +360;
%         phArray(and(phArray >= 150, phArray <= 200)) = -180;
%         phArray(and(phArray <= -150, phArray >= -200)) = 180;
        sortData.phase(grpIdx(j):grpIdxEnd(j)) = sortData.phase(grpIdx(j):grpIdxEnd(j)) + phArray;
      
    end

    phase.mean = arrayfun(@(a,b) mean(sortData.phase(a:b)), grpIdx, grpIdxEnd);
    phase.std = arrayfun(@(a,b) std(sortData.phase(a:b)), grpIdx, grpIdxEnd);
    phase.sdom = phase.std./sqrt(nReps);

 

    %% PLOT RESULTS 
    Nfigs = 20;         % Max number of plots (figures)        
    H.WithErrorBar = gobjects(Nfigs);
    H.PlotOnly     = gobjects(Nfigs);
    lgdFontSize = 8;

    % set plot window size
    plot_height = 800;
    plot_width = 1000;
       
    % Custom Colormap
    RGBColors = [0 0 255    % Blue
                 0 255 255  % Cyan   
                 0 255 0    % Green
                 255 0 255  % Magenta
                 255 0 0    % Red
                 128 0 0    % Maroon
                 0 0 0      % Black
                 ];
             
    mycmap = createColorMap(RGBColors);
    colormap(mycmap);    
    cmap = mycmap(int16(linspace(1,255,nFiles)),:);

    fileName=strrep(file,'_','\_');
    
    %% Bode Plot 
    fignum = 1;    
    tstFig(fignum) = figure(fignum);
    set(tstFig(fignum), 'Position', [900 100 plot_width plot_height])    
        
    % Plot Bode Magnitude
    subplot(2,1,1);      
    hold on;    
   H.WithErrorBar(fignum) = errorbar(uniqFreq, mag.mean,...   
        2*mag.sdom, 2*mag.sdom,...        
        'Color', '#FF0000', ...
        'LineStyle', 'none', ...
        'Marker', 'o' ...      
    );       
   H.PlotOnly(fignum,i) = plot(uniqFreq, mag.mean,...        
        'Color', cmap(i,:), ...
        'LineStyle', '-', ...
        'Marker', 'o', ...                 
        'DisplayName', 'bb' ...
    );              
    hold off;
    title('Title');
    xlabel('Frequency [Hz]')
    if isequal(dB_unit, true)
        ylabel('Magnitude, [dB]');
    else
        ylabel('Magnitude');
    end
    grid on;    
%     lgd = legend(H.PlotOnly(fignum,1:nSets));
%     lgd.FontSize = lgdFontSize;
%     lgd.Location = 'northeast';
    
    % Plot Bode Phase
    subplot(2,1,2); 
    hold on;
    
    H.WithErrorBar(fignum) = errorbar(uniqFreq, phase.mean,...
        2*phase.sdom, 2*phase.sdom,...        
        'Color', cmap(i,:), ...
        'LineStyle', 'none', ...
        'Marker', 'd' ...      
    );
    H.PlotOnly(fignum) = plot(uniqFreq, phase.mean,...        
        'Color', cmap(i,:), ...
        'LineStyle', '-', ...
        'Marker', 'None', ...
        'DisplayName', 'bb' ...
    );            
    
%     lgd = legend(H.PlotOnly(fignum,1:nSets));
%     lgd.FontSize = lgdFontSize;
%     lgd.Location = 'northeast';
    hold off;
    %set(H.WithErrorBar(fignum, [2]), 'Visible', viz);          
    xlabel('Frequency [Hz]')
    ylabel('Phase Angle, [deg]')    
    grid on;  
   
end




%% Determine the number of rows in the file header
function n = headerCount(filename)
  % utility to determine the number of row the header consumes.
  [fid, msg] = fopen(filename);
  if fid < 0
    error('Failed to open file "%s" because "%s"', filename, msg);
  end
    n = 0;
    while true
        t = fgetl(fid);
        if ~ischar(t)
            break;
        else   
            % use regular expression to determine if any non-numeric
            % characters exist which would be assumed to be part of the
            % header (excluding: NaN  and engineering - e.g. 1e-6)
            nChar = regexp(t, '[^0-9.\-\+NaeE \f\n\r\t ]|^\t', 'once');
            if isempty(nChar) && ~isempty(t)                
                break;                
            end
            n = n + 1;            
        end
    end
    fclose(fid);
        
end


function colorMap = createColorMap(RGBColors)
    RGBColors = RGBColors./255;
    Ncolors = size(RGBColors,1);
    colorIndices = linspace(0,1,Ncolors);
    colorMap = interp1(colorIndices,RGBColors,linspace(0,1,255));
end




