%% ssc_flex
% ME495 Flexible shaft experiment
% SimScape Model - generate Bode plot
% Written by: John Laidlaw (5/10/2022)
% Last Updated: 6/6/2022

% Clear workspace
if exist('importUserData', 'var')
    if isequal(importUserData, true)
        clearvars;
        importUserData = true;
    else
        clearvars;
        importUserData = false;
    end
else
    clearvars;
    importUserData = false;
end


%% import the data file obtained from Labview
if isequal(importUserData, true)
    [uniqFreq, mag, phase] = getTestData(true);
end


%% Construct the model using system parameters
K_m             = 0.097;    % N-m/A or V/(rad/sec)
R_m             = 1.6;      % Ohms
L_m             = 0.002;    % Henry
J_m             = 4.23e-5;  % Kg-m^2
D_flywheel      = 0.137;    % m
L_flywheel      = 0.0127;   % m
rho_flywheel    = 7755;     % kg/m^3
D_shaft         = 3.18e-3;  % m
L_shaft         = 0.305;    % m
G_shaft         = 7.31e10;  % N/m^2


% Computed parameters
J_f = rho_flywheel*pi*D_flywheel^4*L_flywheel/32;
K  = pi*G_shaft*D_shaft^4/(32*L_shaft);
J_c = J_m + J_f;

% Key in the damping terms you obtained in the following two lines
B_s 		    = 0.003;		% Type in your value here [N*m*s/rad]
B_b             = 0.003;		% Type in your value here [N*m*s/rad]
B_m             = 0.003;        % Type in your value here [N*m*s/rad]
T_brkawy        = 0.005;        % Type in your value here (Breakaway friction torque) [N*m]
V_brkawy        = 0.001;        % Type in your value here (Breakaway friction velocity) [rads/s]
T_coulomb       = 0.001;        % Type in your value here (Coulomb friction) [N*m]


%% Run SimScape Simulation
freqArray = 1:.1:10;  %Hz
%get_param(bdroot,'FixedStep');

mag_sim = zeros(1,numel(freqArray));
phase_sim = zeros(1,numel(freqArray));
phase_sim_rad = zeros(1,numel(freqArray));

for i = 1:length(freqArray)   
   freq = freqArray(i) * 2*pi;  % rads/s
   z=sim('ssc_flexshaft', 5);		% simulate for 5 seconds  
   %z = sim('ssc_flexshaft', 'StartTime','0','StopTime','5','FixedStep','0.01');
   mag_sim(i) = std(omega2(floor(size(omega2,1)/2):size(omega2,1)))/0.7071;    
								% input voltage amp=1 [A*sin(wt)], std=0.7071;   
   %phase_sim(i) = phshiftmeasure(Vm.signals.values,omega2) * 180/pi;
   y1_h = hilbert(Vm.signals.values);
   y2_h = hilbert(omega2);
   phase_sim_rad(i) = mean((angle(y2_h ./ y1_h)));   
end

phase_sim = unwrap(phase_sim_rad) .* 180./pi;

%% PLOT RESULTS 
Nfigs = 5;         % Max number of plots (figures)        
H.WithErrorBar = gobjects(Nfigs,2);
H.PlotOnly     = gobjects(Nfigs,2);
lgdFontSize = 8;

% set plot window size
plot_height = 800;
plot_width = 1000;

%% Bode Plot 
fignum = 1;    
tstFig(fignum) = figure(fignum);
set(tstFig(fignum), 'Position', [900 100 plot_width plot_height])    
    
% Plot Bode Magnitude
subplot(2,1,1);      
hold on;    
 H.WithErrorBar(fignum,1) = plot(freqArray, 20*log10(mag_sim), ...
     'Color', '#0000FF', ...
     'LineStyle','-', ...
     'Marker', 'none' ...     
 );
if (importUserData)
    H.WithErrorBar(fignum,2) = errorbar(uniqFreq, mag.mean,...   
        2*mag.sdom, 2*mag.sdom,...        
        'Color', '#FF0000', ...
        'LineStyle', 'none', ...
        'Marker', 'o' ...              
    );    
    legend('Simulation', 'Test Data', 'Location', 'northeast');
end
hold off;
title('ME495: Flexible Shaft (Fixture #2)');
xlabel('Frequency [Hz]')
ylabel('Magnitude: $ \left|{\dot{\theta}_2}/{V_m} \right|$ (dB)', 'Interpreter','latex')
grid on;    

% Plot Bode Phase
subplot(2,1,2); 
hold on;
 H.WithErrorBar(fignum,1) = plot(freqArray, phase_sim, ...
     'Color', '#0000FF', ...
     'LineStyle','-', ...
     'Marker', 'none' ...     
 );
if (importUserData)
    H.WithErrorBar(fignum,2) = errorbar(uniqFreq, phase.mean,...
        2*phase.sdom, 2*phase.sdom,...        
        'Color', '#FF0000', ...
        'LineStyle', 'none', ...
        'Marker', 'o' ...      
    );
    legend('Simulation', 'Test Data', 'Location', 'northeast');
end   
hold off;
xlabel('Frequency [Hz]')
ylabel('Phase Angle, [deg]')    
grid on;  
   




%% Import LabView test data files
function [uniqFreq, mag, phase] = getTestData(repPhaseWrap)    
    if nargin == 0
        repPhaseWrap = false;
    end

    %% Define file path and names
    % Get username/user directory
    if ismac
        % Mac platform
        userdir = getenv('HOME');
    elseif isunix
        % Linux platform
        userdir = getenv('HOME');  % Unsure (?)
    elseif ispc
        % Windows platform
        userdir= getenv('USERPROFILE');
    else
        disp('Platform not supported')
    end    
           
    % Assemble user's desktop path
    mydesktop = strcat(userdir,'\desktop\');            
    filter = {'*.*', '*.*';};
    
    % Get data files (File Explorer) - MultiSelect to plot several series
    [file,path] = uigetfile(filter,'Select One or More Data Files', mydesktop, 'MultiSelect', 'on');
    
    if ~isequal(file,0) && ~iscell(file)
        file = cellstr(file);
    end
    
    % Number of data files selected to plot
    nFiles = numel(file); 
    
    if ~isempty(file)
        
        %% Initialize arrays
        fd = cell(nFiles,1);            % cell array of file data
        raw = cell(nFiles,1);
        colHeaders = cell(nFiles,1);        
        N = zeros(nFiles,1);
    
        %% Import tab-delimited data files (from LabView)
        for i = 1:nFiles
            % Construct full file path of data.        
            fullPath = strcat(path,file{i});
    
            % Determine the number or rows for the file header
            headerRowCnt = headerCount(fullPath);
                    
            % Import data files and parse to cell array
            fd{i} = importdata(fullPath, '\t', headerRowCnt);
            
            % if the data file has been edited in Excel (or text editor), the
            % header text is lumped in a single cell of the cell array rather
            % than a separate cell array for each column. 
            if isequal(size(fd{i}.textdata,2),1)
                nCol = size(fd{i}.data,2);
                
                % remove blank rows from textdata                     
                fd{i}.textdata = strip(fd{i}.textdata);
                fd{i}.textdata = fd{i}.textdata(not(cellfun(@(x) isempty(x),fd{i}.textdata)));
                
                % transform to uniform,  multi-column cell array
                nRow = size(fd{i}.textdata,1);
                mycell = cell(nRow, nCol);            
                for ki = 1:nRow
                    ww = strsplit(string(fd{i}.textdata(ki)),'\t');
                    for kj = 1:numel(ww)
                       mycell{ki,kj} = ww{kj};                
                    end                
                end            
                fd{i}.textdata = mycell;            
                fd{i}.colheaders = fd{i}.textdata(end,:);            
            end        
                    
            % Parse data into variables
            raw{i}.freq = round(fd{i}.data(:,1),1);          % frequency (Hz)
            raw{i}.current = fd{i}.data(:, 2);      % motor current
            raw{i}.mag = fd{i}.data(:, 3);          % Bode magnitude        
            raw{i}.phase = fd{i}.data(:, 4);        % Bode phase angle     
            colHeaders{i} = string(fd{i}.colheaders);                
            
            % number of data points
            N(i) = numel(raw{i}.freq);
    
        end
        
        % Combine data files
        cellData= cellfun(@(c) struct2cell(c), raw, 'UniformOutput', false);
        cellData2D = horzcat(cellData{:});
        catCellRows = arrayfun(@(row) cat(1,cellData2D{row,:}), (1:size(cellData2D,1))','UniformOutput', false);
        cboData = cell2struct(catCellRows,fieldnames(raw{1}),1);
        
        % sort all data based on frequency field 
        [~, idx] = sort([cboData.freq]);
        sortData = structfun(@(s) s(idx), cboData, 'UniformOutput', false);
    
        % get array of unique frequencies (to handle replication)
        [uniqFreq, grpIdx, ix] = unique(sortData.freq);
        nReps = accumarray(ix,1);
        
        grpIdxEnd = vertcat(grpIdx(2:end), numel(sortData.freq));
        mag.mean = arrayfun(@(a,b) mean(sortData.mag(a:b)), grpIdx, grpIdxEnd);
        mag.std = arrayfun(@(a,b) std(sortData.mag(a:b)), grpIdx, grpIdxEnd);
        mag.sdom = mag.std./sqrt(nReps);
    
        % Repair phase wrap before proceeding.
        if isequal(repPhaseWrap, true)
            phDiff = arrayfun(@(a,b) round(sortData.phase(a:b)-median(sortData.phase(a:b)),-2),grpIdx, grpIdxEnd, 'UniformOutput', false);
            for j=1:numel(phDiff)-1    
                phArray = cell2mat(phDiff(j));        
                phArray(phArray >= 300) = -360;
                phArray(phArray <= -300) = +360;
        %         phArray(and(phArray >= 150, phArray <= 200)) = -180;
        %         phArray(and(phArray <= -150, phArray >= -200)) = 180;
                sortData.phase(grpIdx(j):grpIdxEnd(j)) = sortData.phase(grpIdx(j):grpIdxEnd(j)) + phArray;
              
            end
        end

        phase.mean = arrayfun(@(a,b) mean(sortData.phase(a:b)), grpIdx, grpIdxEnd);
        phase.std = arrayfun(@(a,b) std(sortData.phase(a:b)), grpIdx, grpIdxEnd);
        phase.sdom = phase.std./sqrt(nReps);        
    end
end

     
%% Determine/Estimate Phase Shift
function PhShift = phshiftmeasure(a, b)
    % represent the signals as column-vectors
    a = a(:);
    b = b(:);
    % remove the DC component of the signals
    a = a - mean(a);
    b = b - mean(b);
    % signals length calculation
    xlen = length(a);
    ylen = length(b);
    % windows generation
    xwin = hanning(xlen, 'periodic');
    ywin = hanning(ylen, 'periodic');
    % perform fft on the signals
    A = fft(a.*xwin); 
    B = fft(b.*ywin);
    % fundamental frequency detection
    [~, indx] = max(abs(A));
    [~, indy] = max(abs(B));
    % phase difference estimation
    PhShift = angle(B(indy)) - angle(A(indx));
end


%% Determine the number of rows in the file header
function n = headerCount(filename)
  % utility to determine the number of row the header consumes.
  [fid, msg] = fopen(filename);
  if fid < 0
    error('Failed to open file "%s" because "%s"', filename, msg);
  end
    n = 0;
    while true
        t = fgetl(fid);
        if ~ischar(t)
            break;
        else   
            % use regular expression to determine if any non-numeric
            % characters exist which would be assumed to be part of the
            % header (excluding: NaN  and engineering - e.g. 1e-6)
            nChar = regexp(t, '[^0-9.\-\+NaeE \f\n\r\t ]|^\t', 'once');
            if isempty(nChar) && ~isempty(t)                
                break;                
            end
            n = n + 1;            
        end
    end
    fclose(fid);
        
end
